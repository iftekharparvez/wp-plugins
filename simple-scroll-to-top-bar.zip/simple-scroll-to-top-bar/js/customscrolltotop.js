jQuery(document).ready(function(){

    jQuery.scrollUp();

});