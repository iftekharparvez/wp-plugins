<?php

/**
 * Plugin Name:       Simple Scroll To Top Bar
 * Description:       Add scroll bar for your wordpress theme. You can use it easily.
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Iftekhar Parvez
 * Author URI:        https://mdiftekhar.info
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       simplescrolltotopbar
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly  
 
 class Scrolltotop{
 
     public function __construct(){
 
        //JS AND CSS file include
        add_action( 'wp_enqueue_scripts', array($this, 'scrolltotop_script_css_func') );

        //register menu item in dashboard
        add_action('admin_init', array($this, 'scrolltotopbar_register_settings'));

        // add menu item
        add_action('admin_menu', array($this, 'scrolltotopbar_menu'));

        // custom css load on head
        add_action( 'wp_head', array($this, 'simplescrolltotop_styles') );

     }
 
     public function scrolltotop_script_css_func(){
        
        //css file include
        wp_enqueue_style( 'scrolltotopbar-style', plugins_url( 'css/simplescrolltotopbar-style.css', __FILE__ ) );


        // js file inlclude
        wp_enqueue_script( 'simplescrolltotopbar-plugin', plugins_url( 'js/simplescrolltotopbar-plugin.js', __FILE__ ), array('jquery'),'1.0.0', true );

        //custom js inlcude
        wp_enqueue_script( 'customscrolltotop', plugins_url( 'js/customscrolltotop.js', __FILE__ ), array('jquery','simplescrolltotopbar-plugin'),'', true );

     }


    // Register and define the settings
    public function scrolltotopbar_register_settings() {
        register_setting('scrolltotopbar_settings', 'background_color');

        register_setting('scrolltotopbar_settings', 'border-radius');

        register_setting('scrolltotopbar_settings', 'image_width');
        register_setting('scrolltotopbar_settings', 'image_height');


     
    }

    // Add a menu item under the "Settings" menu
    public function scrolltotopbar_menu() {
        add_menu_page('Scroll Bar Settings', 'Scroll To Top Bar', 'manage_options', 'scrolltotopbar-settings-id', array($this, 'scrolltotopbar_settings_page'), plugins_url( 'img/images.png', __FILE__ ));
    }

   

    // Function to display the settings page
    public function scrolltotopbar_settings_page() {

        

        ?>

        <div class="wrap">

            <h2>Scroll Bar Settings</h2>
            <form method="post" action="options.php" enctype="multipart/form-data"> <!-- Add enctype for file upload -->
                <?php
                    settings_fields('scrolltotopbar_settings');
                    do_settings_sections('scrolltotopbar_settings');
                ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row">Background Color</th>
                        <td><input type="color" name="background_color" value="<?php echo esc_attr(get_option('background_color')); ?>" /></td>
                    </tr>
                
                    <tr valign="top">
                        <th scope="row">Border Radius</th>
                        <td>
                            <input type="text" name="border-radius" value="<?php echo esc_attr(get_option('border-radius')); ?>" />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Width</th>
                        <td>
                            <input type="text" name="image_width" value="<?php echo esc_attr(get_option('image_width')); ?>" />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row">Height</th>
                        <td>
                            <input type="text" name="image_height" value="<?php echo esc_attr(get_option('image_height')); ?>" />
                        </td>
                    </tr>


                </table>

                <?php submit_button(); ?>
            </form>
        </div>

        <?php
        }


    public function simplescrolltotop_styles(){
        ?>

        <style>
            #scrollUp{
                
                background-color: <?php echo esc_attr(get_option('background_color')); ?>;
                border-radius: <?php echo esc_attr(get_option('border-radius')); ?>;
                width: <?php echo esc_attr(get_option('image_width')); ?>;
                height: <?php echo esc_attr(get_option('image_height')); ?>;
            }
        </style>

        <?php
    }
  








 
 }
 
 $scrollobj = new Scrolltotop();
 
 







?>