=== Simple scrollTotop bar ===
Contributors: iftekhar parvez
Donate link: https://www.buymeacoffee.com/iftekharpax
Tags: simple scrollbar, scrolltotop bar, Scroll bar, easy use scroll, simple scrolling
Requires at least: 6.2
Requires PHP: 7.4
Tested up to: 6.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Just another simple scrolltotop bar plugin. Simple but flexible.

== Description ==

Simple scrolltotop bar can manage sinle options in dashboard, plus you can customize the settings with simple markup. You can change any options easily.

= Docs and support =
Just install and activate.



== Installation ==

1. Upload the entire `simple-scroll-to-top-bar` folder to the `/wp-content/plugins/` directory.
1. Activate the plugin through the **Plugins** screen (**Plugins > Installed Plugins**).

You will find **scroll to top bar** menu in your WordPress admin screen.


== Screenshots ==

1. screenshot1.png

